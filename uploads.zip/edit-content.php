<?php
session_start();
require_once 'database.php';
require_once 'includes/sidebar-counts.php';
require_once 'includes/admin-layout.php';

// ============================================================
// UPLOAD DEBUGGING — Enable temporarily if uploads keep failing
// ============================================================
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

require_once 'includes/auth.php';
requireAdmin();

$is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
$is_staff = (isset($_SESSION['role']) && $_SESSION['role'] === 'staff');


// ✅ Load SystemLogger
if (file_exists('includes/SystemLogger.php')) {
    require_once 'includes/SystemLogger.php';
}

// Get user info
$user_info = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user_info = $stmt->fetch();
} catch (PDOException $e) {
    $user_info = [];
}

// ============================================================
// ✅ NEW: Resolve avatar (photo or initial) — same as admin-profile.php
// ============================================================
if (!function_exists('getAdminAvatar')) {
    function getAdminAvatar($user_info) {
        if (empty($user_info['profile_photo'])) return null;
        $user_id = (int)($user_info['id'] ?? 0);
        if ($user_id <= 0) return null;

        $paths = [
            'uploads/profile/user_' . $user_id . '/' . $user_info['profile_photo'],
            'uploads/staff/' . $user_info['profile_photo'],
            'uploads/profile/' . $user_info['profile_photo'],
        ];
        foreach ($paths as $path) {
            if (file_exists($path) && !is_dir($path)) return $path;
        }
        return null;
    }
}

$admin_avatar       = getAdminAvatar($user_info);
$admin_initial      = strtoupper(substr($user_info['fullname'] ?? $user_info['username'] ?? 'U', 0, 1));
$admin_display_name = $user_info['fullname'] ?? $user_info['username'] ?? 'User';

// ✅ NEW: Helper — build the "Admin 'username'" prefix for logs
if (!function_exists('logActor')) {
    function logActor(array $user_info): string {
        if (!empty($user_info['username'])) {
            return "Admin '{$user_info['username']}'";
        }
        return "User '" . ($_SESSION['username'] ?? 'Unknown') . "'";
    }
}

// ============================================================
// ✅ SIDEBAR BADGE COUNTS — Booking, Reviews, System Logs
// ============================================================




// ============================================================
// HOSTING-SAFE DIRECTORY CREATION
// ============================================================
$upload_dirs = [
    'uploads/gcash/',
    'uploads/logos/',
    'uploads/hero/',
    'uploads/hero/houses/',
    'uploads/hero/tours/',
    'uploads/hero/activities/',
    'uploads/hero/food/',
];

foreach ($upload_dirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

// ============================================================
// HELPER: Reusable image uploader (hosting-safe)
// ============================================================
if (!function_exists('handleImageUpload')) {
    function handleImageUpload($fileKey, $targetDir, $targetBaseName, $allowedExtCsv = 'jpg,jpeg,png,gif,webp') {
        if (!isset($_FILES[$fileKey])) {
            return ['success' => false, 'message' => 'No file received.'];
        }
        $file = $_FILES[$fileKey];
        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            return ['success' => false, 'message' => 'Please select a file to upload.'];
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errMap = [
                UPLOAD_ERR_INI_SIZE   => "File exceeds server's upload_max_filesize (" . ini_get('upload_max_filesize') . ").",
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds the form MAX_FILE_SIZE limit.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded. Please try again.',
                UPLOAD_ERR_NO_TMP_DIR => 'Server has no temporary folder for uploads. Contact your host.',
                UPLOAD_ERR_CANT_WRITE => 'Server could not write the file to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload was stopped by a server extension.',
            ];
            return ['success' => false, 'message' => $errMap[$file['error']] ?? 'Unknown upload error.'];
        }
        if (!is_dir($targetDir)) @mkdir($targetDir, 0755, true);
        if (!is_dir($targetDir)) {
            return ['success' => false, 'message' => "Upload folder could not be created: $targetDir"];
        }
        if (!is_writable($targetDir)) {
            @chmod($targetDir, 0755);
            if (!is_writable($targetDir)) {
                return ['success' => false, 'message' => "Upload folder is not writable: $targetDir. Set permissions to 755 (or 775)."];
            }
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExt = array_map('trim', explode(',', $allowedExtCsv));
        if (!in_array($ext, $allowedExt, true)) {
            return ['success' => false, 'message' => "Invalid file extension (.$ext). Allowed: " . implode(', ', $allowedExt)];
        }
        $allowedMime = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $mime = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        } elseif (function_exists('mime_content_type')) {
            $mime = mime_content_type($file['tmp_name']);
        } else {
            $mime = $file['type'] ?? '';
        }
        if (!in_array($mime, $allowedMime, true)) {
            return ['success' => false, 'message' => "File is not a valid image (detected: $mime)."];
        }
        $targetFilename = $targetBaseName . '.' . $ext;
        $targetPath = rtrim($targetDir, '/') . '/' . $targetFilename;
        foreach (glob(rtrim($targetDir, '/') . '/' . $targetBaseName . '.*') as $oldFile) {
            @unlink($oldFile);
        }
        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            $lastErr = error_get_last();
            $detail = ($lastErr && !empty($lastErr['message'])) ? ' ' . $lastErr['message'] : '';
            return ['success' => false, 'message' => "Failed to save file.$detail Check that $targetDir is writable."];
        }
        @chmod($targetPath, 0644);
        return ['success' => true, 'message' => 'Uploaded successfully.', 'filename' => $targetFilename];
    }
}

// ============================================================
// HELPER: Update / insert a site_content row
// ============================================================
if (!function_exists('saveSiteContent')) {
    function saveSiteContent(PDO $pdo, string $section, string $key, string $value): void {
        $check = $pdo->prepare("SELECT id FROM site_content WHERE section_name = ? AND content_key = ?");
        $check->execute([$section, $key]);
        if ($check->fetch()) {
            $stmt = $pdo->prepare("UPDATE site_content SET content_value = ? WHERE section_name = ? AND content_key = ?");
            $stmt->execute([$value, $section, $key]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO site_content (section_name, content_key, content_value) VALUES (?, ?, ?)");
            $stmt->execute([$section, $key, $value]);
        }
    }
}

// ============================================================
// LOGO UPLOAD
// ============================================================
if (isset($_POST['upload_logo']) && $is_admin) {
    $result = handleImageUpload('logo_image', 'uploads/logos/', 'logo');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'logo_path', 'uploads/logos/' . $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " updated the website logo",
                null, 'site_content', null,
                ['file' => 'uploads/logos/' . $result['filename']]);
        }

        $_SESSION['flash_success'] = "Website logo updated successfully.";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}

// HERO IMAGE UPLOADS
if (isset($_POST['upload_home_hero']) && $is_admin) {
    $result = handleImageUpload('home_hero_image', 'uploads/hero/', 'hero-bg');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'hero_image_path', 'uploads/hero/' . $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new Homepage hero image",
                null, 'site_content', null,
                ['file' => 'uploads/hero/' . $result['filename']]);
        }

        $_SESSION['flash_success'] = "Homepage hero image uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}
if (isset($_POST['upload_houses_hero']) && $is_admin) {
    $result = handleImageUpload('houses_hero_image', 'uploads/hero/houses/', 'houses-hero');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'houses_hero_image', $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new Houses page hero image",
                null, 'site_content', null,
                ['file' => $result['filename']]);
        }

        $_SESSION['flash_success'] = "Houses page hero image uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}
if (isset($_POST['upload_tours_hero']) && $is_admin) {
    $result = handleImageUpload('tours_hero_image', 'uploads/hero/tours/', 'tours-hero');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'tours_hero_image', $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new Tours page hero image",
                null, 'site_content', null,
                ['file' => $result['filename']]);
        }

        $_SESSION['flash_success'] = "Tours page hero image uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}
if (isset($_POST['upload_activities_hero']) && $is_admin) {
    $result = handleImageUpload('activities_hero_image', 'uploads/hero/activities/', 'activities-hero');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'activities_hero_image', $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new Activities page hero image",
                null, 'site_content', null,
                ['file' => $result['filename']]);
        }

        $_SESSION['flash_success'] = "Activities page hero image uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}
if (isset($_POST['upload_food_hero']) && $is_admin) {
    $result = handleImageUpload('food_hero_image', 'uploads/hero/food/', 'food-hero');
    if ($result['success']) {
        saveSiteContent($pdo, 'site_settings', 'food_hero_image', $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new Food page hero image",
                null, 'site_content', null,
                ['file' => $result['filename']]);
        }

        $_SESSION['flash_success'] = "Food page hero image uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}

// GCASH QR CODE UPLOAD
if (isset($_POST['upload_gcash_qr']) && $is_admin) {
    $result = handleImageUpload('gcash_qr', 'uploads/gcash/', 'gcash_qr');
    if ($result['success']) {
        saveSiteContent($pdo, 'gcash', 'qr_code', $result['filename']);

        if (class_exists('SystemLogger')) {
            SystemLogger::log($pdo, 'upload', 'content',
                logActor($user_info) . " uploaded a new GCash QR code",
                null, 'site_content', null,
                ['file' => 'uploads/gcash/' . $result['filename']]);
        }

        $_SESSION['flash_success'] = "GCash QR Code uploaded successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } else { $error = $result['message']; }
}

// ============================================================
// REMOVALS
// ============================================================
if (isset($_POST['remove_logo']) && $is_admin) {
    foreach (glob('uploads/logos/logo.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='logo_path'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the website logo",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Website logo removed. Default branding will be used.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_home_hero']) && $is_admin) {
    foreach (glob('uploads/hero/hero-bg.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='hero_image_path'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the Homepage hero image",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Homepage hero image removed successfully.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_houses_hero']) && $is_admin) {
    foreach (glob('uploads/hero/houses/houses-hero.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='houses_hero_image'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the Houses page hero image",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Houses page hero image removed successfully.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_tours_hero']) && $is_admin) {
    foreach (glob('uploads/hero/tours/tours-hero.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='tours_hero_image'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the Tours page hero image",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Tours page hero image removed successfully.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_activities_hero']) && $is_admin) {
    foreach (glob('uploads/hero/activities/activities-hero.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='activities_hero_image'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the Activities page hero image",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Activities page hero image removed successfully.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_food_hero']) && $is_admin) {
    foreach (glob('uploads/hero/food/food-hero.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='site_settings' AND content_key='food_hero_image'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the Food page hero image",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "Food page hero image removed successfully.";
    header("Location: edit-content.php"); exit();
}
if (isset($_GET['remove_gcash_qr']) && $is_admin) {
    foreach (glob('uploads/gcash/gcash_qr.*') as $f) @unlink($f);
    $pdo->prepare("DELETE FROM site_content WHERE section_name='gcash' AND content_key='qr_code'")->execute();

    if (class_exists('SystemLogger')) {
        SystemLogger::log($pdo, 'delete', 'content',
            logActor($user_info) . " removed the GCash QR code",
            null, 'site_content', null, null, 'warning');
    }

    $_SESSION['flash_success'] = "GCash QR code removed successfully.";
    header("Location: edit-content.php"); exit();
}

// FLASH MESSAGES
if (isset($_SESSION['flash_success'])) {
    $success = $_SESSION['flash_success'];
    unset($_SESSION['flash_success']);
}

// LOAD SITE CONTENT
$content = [];
try {
    $stmt = $pdo->query("SELECT * FROM site_content ORDER BY section_name, id");
    while ($row = $stmt->fetch()) {
        $content[$row['section_name']][$row['content_key']] = $row['content_value'];
    }
} catch (Exception $e) { $error = "Failed to load content: " . $e->getMessage(); }

$site_name = $content['site_settings']['site_name'] ?? 'Transient House & Tours';

// RESOLVE IMAGE PATHS WITH GLOB FALLBACK
$logo_path = $content['site_settings']['logo_path'] ?? '';
$logo_exists = false;
if (!empty($logo_path) && file_exists($logo_path) && !is_dir($logo_path)) {
    $logo_exists = true;
} else {
    foreach (glob('uploads/logos/logo.*') as $f) {
        $logo_path = $f; $logo_exists = true;
        saveSiteContent($pdo, 'site_settings', 'logo_path', $f); break;
    }
}

$home_hero_path = $content['site_settings']['hero_image_path'] ?? '';
$home_hero_exists = false;
if (!empty($home_hero_path) && file_exists($home_hero_path) && !is_dir($home_hero_path)) {
    $home_hero_exists = true;
} else {
    foreach (glob('uploads/hero/hero-bg.*') as $f) {
        $home_hero_path = $f; $home_hero_exists = true;
        saveSiteContent($pdo, 'site_settings', 'hero_image_path', $f); break;
    }
}

$houses_hero_filename = $content['site_settings']['houses_hero_image'] ?? '';
$houses_hero_path = 'uploads/hero/houses/' . $houses_hero_filename;
$houses_hero_exists = !empty($houses_hero_filename) && file_exists($houses_hero_path);
if (!$houses_hero_exists) {
    foreach (glob('uploads/hero/houses/houses-hero.*') as $f) {
        $houses_hero_path = $f; $houses_hero_exists = true;
        saveSiteContent($pdo, 'site_settings', 'houses_hero_image', basename($f)); break;
    }
}

$tours_hero_filename = $content['site_settings']['tours_hero_image'] ?? '';
$tours_hero_path = 'uploads/hero/tours/' . $tours_hero_filename;
$tours_hero_exists = !empty($tours_hero_filename) && file_exists($tours_hero_path);
if (!$tours_hero_exists) {
    foreach (glob('uploads/hero/tours/tours-hero.*') as $f) {
        $tours_hero_path = $f; $tours_hero_exists = true;
        saveSiteContent($pdo, 'site_settings', 'tours_hero_image', basename($f)); break;
    }
}

$activities_hero_filename = $content['site_settings']['activities_hero_image'] ?? '';
$activities_hero_path = 'uploads/hero/activities/' . $activities_hero_filename;
$activities_hero_exists = !empty($activities_hero_filename) && file_exists($activities_hero_path);
if (!$activities_hero_exists) {
    foreach (glob('uploads/hero/activities/activities-hero.*') as $f) {
        $activities_hero_path = $f; $activities_hero_exists = true;
        saveSiteContent($pdo, 'site_settings', 'activities_hero_image', basename($f)); break;
    }
}

$food_hero_filename = $content['site_settings']['food_hero_image'] ?? '';
$food_hero_path = 'uploads/hero/food/' . $food_hero_filename;
$food_hero_exists = !empty($food_hero_filename) && file_exists($food_hero_path);
if (!$food_hero_exists) {
    foreach (glob('uploads/hero/food/food-hero.*') as $f) {
        $food_hero_path = $f; $food_hero_exists = true;
        saveSiteContent($pdo, 'site_settings', 'food_hero_image', basename($f)); break;
    }
}

$gcash_qr_filename = $content['gcash']['qr_code'] ?? '';
$gcash_qr_path = 'uploads/gcash/' . $gcash_qr_filename;
$gcash_qr_exists = !empty($gcash_qr_filename) && file_exists($gcash_qr_path);
if (!$gcash_qr_exists) {
    foreach (glob('uploads/gcash/gcash_qr.*') as $f) {
        $gcash_qr_path = $f; $gcash_qr_exists = true;
        saveSiteContent($pdo, 'gcash', 'qr_code', basename($f)); break;
    }
}

$facebook_link = $content['social']['facebook'] ?? '#';
$location_address = $content['location']['address'] ?? '123 Transient Street, Alaminos City, Pangasinan';
$google_maps_embed = $content['location']['google_maps_embed'] ?? '';

// ============================================================
// HANDLE CONTENT UPDATE
// ============================================================
if (isset($_POST['update_content']) && $is_admin) {
    try {
        $old_terms_body   = $content['terms']['body']   ?? '';
        $old_privacy_body = $content['privacy']['body'] ?? '';
        $old_terms_title  = $content['terms']['title']  ?? '';
        $old_privacy_title= $content['privacy']['title']?? '';

        if (!empty($_POST['content']) && is_array($_POST['content'])) {
            $locked_content_keys = [
                'hero' => ['stats_houses_label', 'stats_houses_available_label', 'stats_tours_label', 'stats_tours_available_label'],
                'features' => ['section_title', 'feature1_title', 'feature1_desc', 'feature2_title', 'feature2_desc', 'feature3_title', 'feature3_desc', 'feature4_title', 'feature4_desc'],
                'cta' => ['button_houses_text', 'button_tours_text'],
                'footer' => ['address', 'copyright', 'privacy_policy', 'terms_of_service'],
            ];

            foreach ($_POST['content'] as $section => $items) {
                // Terms & Conditions and system-controlled labels are locked by policy.
                if ($section === 'terms') continue;
                if (!is_array($items)) continue;
                foreach ($items as $key => $value) {
                    if (isset($locked_content_keys[$section]) && in_array($key, $locked_content_keys[$section], true)) {
                        continue;
                    }
                    saveSiteContent($pdo, $section, $key, $value);
                }
            }

            // Keep the legacy footer address synchronized for older pages/data consumers.
            if (isset($_POST['content']['location']['address'])) {
                saveSiteContent($pdo, 'footer', 'address', $_POST['content']['location']['address']);
            }
        }

        $new_terms_body   = $old_terms_body;
        $new_privacy_body = $_POST['content']['privacy']['body'] ?? $old_privacy_body;
        $new_terms_title  = $old_terms_title;
        $new_privacy_title= $_POST['content']['privacy']['title']?? $old_privacy_title;

        $terms_changed = ($old_terms_body !== $new_terms_body)
                      || ($old_privacy_body !== $new_privacy_body)
                      || ($old_terms_title !== $new_terms_title)
                      || ($old_privacy_title !== $new_privacy_title);

        if (class_exists('SystemLogger')) {
            $sections = array_values(array_filter(
                array_keys($_POST['content'] ?? []),
                static fn($section) => $section !== 'terms'
            ));
            $field_count = 0;
            foreach (($_POST['content'] ?? []) as $section => $items) {
                if ($section === 'terms') continue;
                if (is_array($items)) $field_count += count($items);
            }

            SystemLogger::log($pdo, 'update', 'content',
                logActor($user_info) . " updated site content ({$field_count} field(s) across " . count($sections) . " section(s): " . implode(', ', $sections) . ")",
                null, 'site_content', null,
                ['sections' => $sections, 'field_count' => $field_count]);

            if ($terms_changed) {
                $new_version = substr(md5(
                    $new_terms_title . $new_terms_body .
                    $new_privacy_title . $new_privacy_body
                ), 0, 8);

                SystemLogger::log($pdo, 'update', 'terms',
                    logActor($user_info) . " updated Privacy Policy (new acceptance version: {$new_version}); Terms & Conditions remained locked",
                    null, 'site_content', null,
                    ['new_version' => $new_version]);
            }
        }

        $_SESSION['flash_success'] = "Content updated successfully!";
        header("Location: edit-content.php?fresh=" . time());
        exit();
    } catch (Exception $e) { $error = "Update failed: " . $e->getMessage(); }
}

if (isset($_GET['logout'])) {
    if (class_exists('SystemLogger') && isset($_SESSION['user_id'])) {
        SystemLogger::log($pdo, 'logout', 'auth',
            "User '" . ($_SESSION['username'] ?? 'Unknown') . "' logged out",
            (int)$_SESSION['user_id'], 'user');
    }
    session_destroy();
    header("Location: index.php");
    exit();
}

$cache_buster = 'v=' . time() . '_' . rand(1000, 9999);

$current_terms_version = substr(md5(
    ($content['terms']['title'] ?? '') .
    ($content['terms']['body'] ?? '') .
    ($content['privacy']['title'] ?? '') .
    ($content['privacy']['body'] ?? '')
), 0, 8);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Edit Content - <?php echo $is_admin ? 'Admin' : 'Staff'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin-layout.css?v=<?php echo (int)@filemtime(__DIR__ . '/assets/css/admin-layout.css'); ?>">
    <style>
        /* Page values that differ from assets/css/admin-layout.css (kept so this page looks exactly as before).
           Delete a line to adopt the shared default. */
        @media (max-width: 1024px) {
            .sidebar { padding-top: 25px; }
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { -webkit-text-size-adjust: 100%; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #f0f7fb;
            min-height: 100vh;
            overflow-x: hidden;
        }
        .sidebar {
            width: 280px;
            background: #0B2447;
            box-shadow: 4px 0 20px rgba(0,0,0,0.2);
            padding: 25px 0;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            border-right: 2px solid rgba(77,166,217,0.15);
            transition: transform 0.3s ease, width 0.3s ease;
            z-index: 100;
            flex-shrink: 0;
        }
        .sidebar::-webkit-scrollbar { width: 5px; }
        .sidebar::-webkit-scrollbar-track { background: rgba(255,255,255,0.05); }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(77,166,217,0.3); border-radius: 10px; }
        .sidebar-header .logo .logo-icon {
            width: 48px; height: 48px;
            background: linear-gradient(135deg, #4DA6D9, #7bb8f0);
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px; color: white; flex-shrink: 0;
            box-shadow: 0 4px 15px rgba(77,166,217,0.3);
            overflow: hidden;
        }
        .sidebar-header .logo .logo-text .sub { font-size: 10px; color: #7bb8f0; font-weight: 400; letter-spacing: 0.3px; }
        .menu-toggle .fa-bars { transition: transform 0.3s ease; }
        .menu-toggle.active .fa-bars { transform: rotate(90deg); }
        @media (max-width: 1024px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                height: 100vh;
                transform: translateX(-100%);
                width: 280px;
                z-index: 1000;
                box-shadow: none;
                border-radius: 0;
            }
            .sidebar.open {
                transform: translateX(0);
                box-shadow: 4px 0 30px rgba(0,0,0,0.4);
            }
        }
        @media (max-width: 480px) {
            .sidebar { width: 85%; max-width: 300px; }
            .sidebar-header .logo .logo-icon { width: 40px; height: 40px; font-size: 18px; }
            .nav-link i { font-size: 14px; }
        }

        @media (max-width: 768px) {

            .top-bar .page-title h1 .mobile-role-badge {
                display: inline-flex;
                align-items: center;
                gap: 5px;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                white-space: nowrap;
            }
        }

        @media (max-width: 480px) {
            .top-bar .page-title h1 .mobile-role-badge { font-size: 10px; padding: 3px 10px; }
        }

        .page-title-banner {
            background: linear-gradient(135deg, #0B2447 0%, #0B3D91 50%, #4DA6D9 100%);
            border-radius: 20px; padding: 30px 35px;
            margin-bottom: 30px; color: white;
            box-shadow: 0 10px 30px rgba(11,36,71,0.15);
            position: relative; overflow: hidden;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .page-title-banner::before {
            content: ''; position: absolute;
            top: -50%; right: -50%; width: 200%; height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }
        @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .page-title-banner .banner-content { position: relative; z-index: 1; }
        .page-title-banner h1 { font-size: 28px; font-weight: 700; margin-bottom: 5px; }
        .page-title-banner h1 i { margin-right: 10px; opacity: 0.9; }
        .page-title-banner .underline { width: 60px; height: 3px; background: white; border-radius: 2px; margin-top: 8px; opacity: 0.5; }
        .page-title-banner p { opacity: 0.85; font-size: 14px; margin: 8px 0 0 0; }
        .page-title-banner p .staff-notice {
            display: inline-block; background: rgba(251,191,36,0.2);
            color: #fbbf24; padding: 2px 12px; border-radius: 20px;
            font-size: 12px; font-weight: 500;
            border: 1px solid rgba(251,191,36,0.2); margin-top: 5px;
        }
        .page-title-banner p .staff-notice i { margin-right: 5px; }
        @media (max-width: 768px) {
            .page-title-banner { padding: 20px; text-align: center; border-radius: 16px; }
            .page-title-banner .underline { margin: 8px auto 0; }
            .page-title-banner h1 { font-size: 22px; }
        }
        @media (max-width: 480px) {
            .page-title-banner { padding: 15px; border-radius: 12px; }
            .page-title-banner h1 { font-size: 18px; }
        }
        .content-section {
            background: white; border-radius: 20px;
            padding: 25px; margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.06);
            border: 1px solid #e8f0fe;
        }
        .content-section h2 {
            font-size: 20px; font-weight: 600; color: #4DA6D9;
            margin-bottom: 20px; padding-bottom: 10px;
            border-bottom: 2px solid #e8f0fe;
        }
        .content-section h2 i { margin-right: 10px; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block; margin-bottom: 8px;
            font-weight: 600; color: #1e293b; font-size: 14px;
        }
        .form-group label i { color: #4DA6D9; margin-right: 5px; }
        .form-control {
            width: 100%; padding: 12px;
            border: 2px solid #e8f0fe; border-radius: 8px;
            font-size: 14px; transition: all 0.2s; background: #fafafa;
            font-family: inherit;
        }
        .form-control:focus {
            outline: none; border-color: #4DA6D9;
            background: white; box-shadow: 0 0 0 3px rgba(77,166,217,0.1);
        }
        .form-control:disabled { background: #f1f5f9; cursor: not-allowed; opacity: 0.7; }
        textarea.form-control { min-height: 100px; resize: vertical; }
        .form-control-readonly { background: #f1f5f9 !important; cursor: not-allowed !important; opacity: 0.7 !important; }
        .preview-section {
            background: #f8fafc; border-radius: 12px;
            padding: 20px; margin-top: 15px;
            text-align: center;
            border: 2px dashed #e8f0fe;
        }
        .preview-section .image-display {
            display: inline-block; padding: 15px;
            background: white; border-radius: 12px;
            border: 2px solid #e8f0fe; margin-bottom: 15px;
            max-width: 100%;
        }
        .preview-section .image-display img {
            max-width: 100%; max-height: 200px;
            border-radius: 8px; display: block; object-fit: cover;
        }
        .preview-section .image-display .placeholder-icon {
            width: 100%; height: 200px;
            background: linear-gradient(135deg, #4DA6D9, #7bb8f0);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 60px;
        }
        .preview-section .status {
            display: inline-block; padding: 3px 12px;
            border-radius: 20px; font-size: 12px;
            font-weight: 600; margin-top: 8px;
        }
        .preview-section .status.active { background: #e6f7e6; color: #10b981; }
        .preview-section .status.inactive { background: #fef3c7; color: #f59e0b; }
        .preview-section .actions {
            display: flex; gap: 10px;
            justify-content: center; flex-wrap: wrap; margin-top: 10px;
        }
        .preview-section .actions .btn-upload {
            background: #4DA6D9; color: white; border: none;
            padding: 10px 25px; border-radius: 8px;
            font-weight: 600; cursor: pointer; transition: all 0.3s;
        }
        .preview-section .actions .btn-upload:hover {
            background: #3a8bbf; transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(77,166,217,0.3);
        }
        .preview-section .actions .btn-remove {
            background: #ef4444; color: white; border: none;
            padding: 10px 25px; border-radius: 8px;
            font-weight: 600; cursor: pointer; transition: all 0.3s;
            text-decoration: none; display: inline-flex;
            align-items: center; gap: 6px;
        }
        .preview-section .actions .btn-remove:hover {
            background: #dc2626; transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(239,68,68,0.3);
        }
        .preview-section .file-input-wrapper {
            position: relative; overflow: hidden; display: inline-block;
        }
        .preview-section .file-input-wrapper input[type="file"] {
            position: absolute; left: 0; top: 0;
            opacity: 0; width: 100%; height: 100%; cursor: pointer;
        }
        .preview-section .file-input-wrapper .custom-file-label {
            display: inline-block; padding: 10px 25px;
            border: 2px dashed #e8f0fe; border-radius: 8px;
            color: #94a3b8; transition: all 0.3s;
            cursor: pointer; font-weight: 500;
        }
        .preview-section .file-input-wrapper .custom-file-label:hover {
            border-color: #4DA6D9; background: #f0f7fb;
        }
        .preview-section .file-input-wrapper .custom-file-label i { margin-right: 8px; color: #4DA6D9; }
        .preview-section .file-input-wrapper .custom-file-label.has-file {
            border-color: #10b981; background: #f0fdf4; color: #10b981;
        }
        .preview-section .file-name-display { font-size: 13px; color: #64748b; margin-top: 10px; }
        .preview-section .size-info { font-size: 12px; color: #94a3b8; margin-top: 5px; }

        /* Website logo manager */
        .logo-content-section { padding: 28px; }
        .logo-section-intro {
            border-bottom: 2px solid #e8f0fe;
            padding-bottom: 16px;
            margin-bottom: 22px;
        }
        .logo-content-section .logo-section-intro h2 {
            border-bottom: 0;
            padding-bottom: 0;
            margin-bottom: 6px;
        }
        .logo-section-intro p {
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
            margin: 0;
        }
        .logo-manager {
            display: grid;
            grid-template-columns: minmax(220px, .78fr) minmax(0, 1.35fr);
            gap: 20px;
            align-items: stretch;
        }
        .logo-panel {
            border: 1px solid #dce8f8;
            border-radius: 16px;
            padding: 20px;
            background: #fbfdff;
        }
        .logo-panel-title {
            font-size: 15px;
            font-weight: 700;
            color: #0B2447;
            margin: 0 0 5px;
        }
        .logo-panel-copy {
            color: #64748b;
            font-size: 12px;
            line-height: 1.55;
            margin: 0 0 16px;
        }
        .logo-card-label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 12px;
            color: #64748b;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .logo-current-preview {
            min-height: 190px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 18px;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
        }
        .logo-current-preview img {
            display: block;
            max-width: 170px;
            max-height: 170px;
            width: auto;
            height: auto;
            object-fit: contain;
            border-radius: 10px;
        }
        .logo-current-placeholder {
            width: 140px;
            height: 140px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #eef6ff, #dcecff);
            color: #4DA6D9;
            font-size: 42px;
            border: 1px solid #d8e8fb;
        }
        .logo-current-details {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            margin-top: 14px;
        }
        .logo-current-name {
            min-width: 0;
        }
        .logo-current-name strong {
            display: block;
            color: #0f172a;
            font-size: 14px;
            line-height: 1.35;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .logo-current-name span {
            display: block;
            color: #94a3b8;
            font-size: 11px;
            margin-top: 3px;
        }
        .logo-status-pill {
            flex: 0 0 auto;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            white-space: nowrap;
        }
        .logo-status-pill.active { background: #ecfdf3; color: #0f9f6e; }
        .logo-status-pill.fallback { background: #fff7ed; color: #c36a09; }
        .logo-upload-dropzone {
            position: relative;
            min-height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 22px;
            border: 2px dashed #cfe0f5;
            border-radius: 14px;
            background: #f8fbff;
            cursor: pointer;
            transition: border-color .2s ease, background .2s ease, box-shadow .2s ease;
            text-align: center;
        }
        .logo-upload-dropzone:hover,
        .logo-upload-dropzone.dragover {
            border-color: #4DA6D9;
            background: #f0f8ff;
            box-shadow: 0 0 0 4px rgba(77,166,217,.08);
        }
        .logo-upload-dropzone input[type="file"] {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
        .logo-dropzone-default,
        .logo-selected-state {
            width: 100%;
            pointer-events: none;
        }
        .logo-upload-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 10px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #e8f4fd;
            color: #4DA6D9;
            font-size: 20px;
        }
        .logo-dropzone-default strong {
            display: block;
            color: #0f172a;
            font-size: 14px;
            margin-bottom: 4px;
        }
        .logo-dropzone-default span {
            display: block;
            color: #64748b;
            font-size: 12px;
        }
        .logo-selected-state {
            display: none;
            align-items: center;
            gap: 14px;
            text-align: left;
        }
        .logo-selected-state.show { display: flex; }
        .logo-selected-preview {
            width: 74px;
            height: 74px;
            flex: 0 0 74px;
            border-radius: 12px;
            background: #fff;
            border: 1px solid #dce8f8;
            object-fit: contain;
            padding: 5px;
        }
        .logo-selected-info { min-width: 0; flex: 1; }
        .logo-selected-info strong {
            display: block;
            color: #0f172a;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .logo-selected-info span {
            display: block;
            color: #64748b;
            font-size: 11px;
            margin-top: 4px;
        }
        .logo-ready-badge {
            flex: 0 0 auto;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 8px;
            border-radius: 999px;
            background: #ecfdf3;
            color: #0f9f6e;
            font-size: 10px;
            font-weight: 700;
        }
        .logo-upload-requirements {
            display: flex;
            align-items: flex-start;
            gap: 7px;
            color: #64748b;
            font-size: 11px;
            line-height: 1.5;
            margin-top: 11px;
        }
        .logo-upload-requirements i { color: #4DA6D9; margin-top: 2px; }
        .logo-save-row {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-top: 16px;
        }
        .logo-save-btn {
            border: 0;
            border-radius: 10px;
            padding: 11px 18px;
            background: #4DA6D9;
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 7px;
            cursor: pointer;
            transition: transform .2s ease, background .2s ease, box-shadow .2s ease;
        }
        .logo-save-btn:hover:not(:disabled) {
            background: #3a8bbf;
            transform: translateY(-1px);
            box-shadow: 0 5px 14px rgba(77,166,217,.25);
        }
        .logo-save-btn:disabled {
            background: #cbd5e1;
            color: #f8fafc;
            cursor: not-allowed;
            box-shadow: none;
        }
        .logo-readonly-panel {
            grid-column: 1 / -1;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            border: 1px solid #fde68a;
            background: #fffbeb;
            color: #92400e;
            border-radius: 14px;
            padding: 14px 16px;
            font-size: 12px;
            line-height: 1.55;
        }
        .logo-readonly-panel i { color: #f59e0b; margin-top: 2px; }
        .logo-danger-zone {
            grid-column: 1 / -1;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 16px 18px;
            border: 1px solid #fecaca;
            border-radius: 14px;
            background: #fffafa;
        }
        .logo-danger-zone strong {
            display: block;
            color: #991b1b;
            font-size: 13px;
            margin-bottom: 3px;
        }
        .logo-danger-zone p {
            color: #7f1d1d;
            font-size: 11px;
            line-height: 1.5;
            margin: 0;
        }
        .logo-remove-button {
            flex: 0 0 auto;
            border: 1px solid #ef4444;
            background: #fff;
            color: #dc2626;
            border-radius: 9px;
            padding: 9px 13px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: background .2s ease, color .2s ease;
        }
        .logo-remove-button:hover { background: #ef4444; color: #fff; }

        .logo-remove-modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 10050;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(2, 18, 38, .58);
            backdrop-filter: blur(3px);
        }
        .logo-remove-modal-overlay.show { display: flex; }
        .logo-remove-modal {
            width: min(430px, 100%);
            background: #fff;
            border-radius: 18px;
            padding: 26px;
            box-shadow: 0 24px 70px rgba(2,18,38,.28);
            text-align: center;
        }
        .logo-remove-modal-icon {
            width: 58px;
            height: 58px;
            margin: 0 auto 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            background: #fee2e2;
            color: #dc2626;
            font-size: 22px;
        }
        .logo-remove-modal h3 {
            color: #0f172a;
            font-size: 18px;
            margin: 0 0 7px;
        }
        .logo-remove-modal p {
            color: #64748b;
            font-size: 12px;
            line-height: 1.6;
            margin: 0 0 20px;
        }
        .logo-remove-modal-actions {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .logo-modal-cancel,
        .logo-modal-confirm {
            border-radius: 9px;
            padding: 10px 16px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .logo-modal-cancel {
            border: 1px solid #cbd5e1;
            background: #fff;
            color: #475569;
        }
        .logo-modal-confirm {
            border: 1px solid #dc2626;
            background: #dc2626;
            color: #fff;
        }
        .logo-modal-cancel:hover { background: #f8fafc; }
        .logo-modal-confirm:hover { background: #b91c1c; }

        @media (max-width: 820px) {
            .logo-manager { grid-template-columns: 1fr; }
            .logo-danger-zone, .logo-readonly-panel { grid-column: auto; }
        }
        @media (max-width: 560px) {
            .logo-content-section { padding: 20px 16px; }
            .logo-panel { padding: 16px; }
            .logo-current-details,
            .logo-danger-zone { align-items: stretch; flex-direction: column; }
            .logo-status-pill { align-self: flex-start; }
            .logo-remove-button { width: 100%; justify-content: center; }
            .logo-selected-state { align-items: flex-start; flex-wrap: wrap; }
            .logo-ready-badge { margin-left: 88px; }
            .logo-save-btn { width: 100%; justify-content: center; }
            .logo-remove-modal-actions { flex-direction: column-reverse; }
            .logo-modal-cancel, .logo-modal-confirm { width: 100%; }
        }

        /* Page banner manager */
        .banner-content-section { padding: 28px; }
        .banner-section-intro {
            border-bottom: 2px solid #e8f0fe;
            padding-bottom: 16px;
            margin-bottom: 18px;
        }
        .banner-content-section .banner-section-intro h2 {
            border-bottom: 0;
            padding-bottom: 0;
            margin-bottom: 6px;
        }
        .banner-section-intro p {
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
            margin: 0;
        }
        .banner-list {
            border: 1px solid #dce8f8;
            border-radius: 16px;
            overflow: hidden;
            background: #fff;
            container-type: inline-size;
        }
        .banner-row {
            display: grid;
            grid-template-columns: minmax(180px, .9fr) 170px minmax(300px, 1.6fr);
            gap: 16px;
            align-items: center;
            padding: 16px 18px;
            border-bottom: 1px solid #e8eef7;
            transition: background .2s ease, box-shadow .2s ease;
        }
        .banner-row:last-child { border-bottom: 0; }
        .banner-row:hover { background: #fbfdff; }
        .banner-row.is-selected {
            background: #f5fbff;
            box-shadow: inset 3px 0 0 #4DA6D9;
        }
        .banner-page {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .banner-page-icon {
            width: 42px;
            height: 42px;
            flex: 0 0 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #edf7fd;
            color: #4DA6D9;
            font-size: 17px;
            border: 1px solid #dcecf8;
        }
        .banner-page-copy { min-width: 0; }
        .banner-page-copy strong {
            display: block;
            color: #0f172a;
            font-size: 14px;
            line-height: 1.35;
        }
        .banner-page-copy span {
            display: block;
            color: #94a3b8;
            font-size: 11px;
            line-height: 1.45;
            margin-top: 3px;
        }
        .banner-thumbnail {
            width: 170px;
            height: 92px;
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            border: 1px solid #dce8f8;
            background: #f8fbff;
        }
        .banner-thumbnail img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }
        .banner-thumbnail-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #edf7fd, #dceeff);
            color: #4DA6D9;
            font-size: 24px;
        }
        .banner-thumbnail-fallback {
            position: absolute;
            left: 7px;
            bottom: 7px;
            padding: 3px 7px;
            border-radius: 999px;
            background: rgba(11,36,71,.82);
            color: #fff;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: .02em;
        }
        .banner-controls {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 168px;
            gap: 16px;
            align-items: center;
            min-width: 0;
        }
        .banner-state { min-width: 0; }
        .banner-status-pill {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            line-height: 1;
        }
        .banner-status-pill.custom { background: #ecfdf3; color: #0f9f6e; }
        .banner-status-pill.fallback { background: #fff7ed; color: #c36a09; }
        .banner-status-pill.ready { background: #eaf5ff; color: #2879ad; }
        .banner-state small {
            display: block;
            margin-top: 6px;
            color: #64748b;
            font-size: 11px;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }
        .banner-actions {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            justify-content: center;
            gap: 7px;
            min-width: 0;
        }
        .banner-file-input {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            padding: 0 !important;
            margin: -1px !important;
            overflow: hidden !important;
            clip: rect(0, 0, 0, 0) !important;
            white-space: nowrap !important;
            border: 0 !important;
        }
        .banner-select-btn,
        .banner-save-btn,
        .banner-reset-btn {
            min-height: 38px;
            border-radius: 9px;
            padding: 9px 12px;
            font-size: 11px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            cursor: pointer;
            transition: background .2s ease, border-color .2s ease, color .2s ease, transform .2s ease;
            white-space: nowrap;
        }
        .banner-select-btn {
            border: 1px solid #cfe0f5;
            background: #fff;
            color: #2879ad;
        }
        .banner-select-btn:hover {
            border-color: #4DA6D9;
            background: #f1f9fe;
            transform: translateY(-1px);
        }
        .banner-save-btn {
            border: 1px solid #4DA6D9;
            background: #4DA6D9;
            color: #fff;
        }
        .banner-save-btn:hover:not(:disabled) {
            background: #3a8bbf;
            border-color: #3a8bbf;
            transform: translateY(-1px);
        }
        .banner-save-btn:disabled {
            display: none;
            border-color: #dbe3ec;
            background: #e2e8f0;
            color: #94a3b8;
            cursor: not-allowed;
        }
        .banner-reset-btn {
            min-height: 32px;
            padding: 6px 9px;
            border: 1px solid transparent;
            background: transparent;
            color: #64748b;
        }
        .banner-reset-btn:hover {
            background: #f8fafc;
            color: #dc2626;
        }
        .banner-readonly {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 600;
        }
        .banner-guidance {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-top: 14px;
            color: #64748b;
            font-size: 11px;
            line-height: 1.55;
        }
        .banner-guidance i { color: #4DA6D9; margin-top: 2px; }
        @container (max-width: 930px) {
            .banner-row {
                grid-template-columns: minmax(170px, 1fr) 150px minmax(230px, 1.35fr);
                gap: 14px;
                padding: 15px 16px;
            }
            .banner-thumbnail { width: 150px; height: 82px; }
            .banner-controls {
                grid-template-columns: 1fr 150px;
                gap: 12px;
            }
        }
        @container (max-width: 760px) {
            .banner-row {
                grid-template-columns: 138px minmax(0, 1fr);
                gap: 12px;
                padding: 14px;
            }
            .banner-page { grid-column: 1 / -1; }
            .banner-thumbnail { width: 138px; height: 76px; }
            .banner-controls {
                grid-template-columns: minmax(0, 1fr) 150px;
                gap: 12px;
            }
        }
        @container (max-width: 560px) {
            .banner-row { grid-template-columns: 1fr; }
            .banner-thumbnail { width: 100%; height: 150px; }
            .banner-controls {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            .banner-actions { width: 100%; }
            .banner-select-btn, .banner-save-btn, .banner-reset-btn { width: 100%; }
        }
        @media (max-width: 760px) {
            .banner-content-section { padding: 20px 16px; }
        }
        .btn-save {
            background: #10b981; color: white; border: none;
            padding: 12px 30px; border-radius: 8px;
            font-size: 14px; font-weight: 600; cursor: pointer;
            transition: all 0.2s; display: inline-flex;
            align-items: center; gap: 8px;
        }
        .btn-save:hover { background: #059669; transform: translateY(-2px); box-shadow: 0 4px 15px rgba(16,185,129,0.3); }
        .btn-save:disabled { background: #cbd5e1; cursor: not-allowed; transform: none; }
        .btn-save:disabled:hover { background: #cbd5e1; transform: none; box-shadow: none; }
        .btn-back {
            background: #64748b; color: white; border: none;
            padding: 12px 25px; border-radius: 8px;
            font-size: 14px; font-weight: 600; cursor: pointer;
            transition: all 0.2s; text-decoration: none;
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-back:hover { background: #475569; transform: translateY(-2px); color: white; }
        .action-buttons {
            display: flex; gap: 15px;
            justify-content: flex-end;
            margin-top: 30px; flex-wrap: wrap;
        }
        .alert {
            padding: 15px 20px; border-radius: 12px;
            margin-bottom: 20px; display: flex;
            align-items: center; gap: 10px;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert-success { background: #e6f7e6; color: #10b981; border-left: 4px solid #10b981; }
        .alert-error { background: #fee2e2; color: #ef4444; border-left: 4px solid #ef4444; }
        .alert i { font-size: 18px; }
        .row { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 20px; }
        h4 { color: #1e293b; margin-bottom: 15px; font-size: 16px; font-weight: 600; }
        .text-muted { color: #64748b; font-size: 12px; margin-top: 5px; }
        .help-text { font-size: 11px; color: #94a3b8; margin-top: 4px; }
        .view-only-banner {
            background: #fef3c7; border: 1px solid #f59e0b;
            border-radius: 12px; padding: 12px 20px;
            margin-bottom: 20px; display: flex;
            align-items: center; gap: 12px; color: #92400e;
        }
        .view-only-banner i { font-size: 20px; color: #f59e0b; }
        .form-section-title {
            font-size: 14px; font-weight: 600; color: #4DA6D9;
            margin: 20px 0 15px; border-bottom: 1px solid #e8f0fe;
            padding-bottom: 10px;
        }
        .section-description {
            margin: -10px 0 22px;
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
        }
        .system-actions-preview {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px;
            padding: 14px 16px;
            background: #f8fafc;
            border: 1px solid #e8f0fe;
            border-radius: 12px;
            color: #64748b;
            font-size: 12px;
        }
        .system-actions-preview strong { color: #1e293b; }
        .system-action-chip {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 10px;
            border-radius: 999px;
            background: white;
            border: 1px solid #dbeafe;
            color: #0B2447;
            font-weight: 600;
        }
        .help-disclosure {
            margin-top: 10px;
            border: 1px solid #e8f0fe;
            border-radius: 10px;
            background: #f8fafc;
            overflow: hidden;
        }
        .help-disclosure summary {
            cursor: pointer;
            list-style: none;
            padding: 11px 13px;
            font-size: 12px;
            font-weight: 600;
            color: #475569;
        }
        .help-disclosure summary::-webkit-details-marker { display: none; }
        .help-disclosure summary i { color: #4DA6D9; margin-right: 7px; }
        .help-disclosure__body {
            padding: 0 13px 13px;
            color: #64748b;
            font-size: 12px;
            line-height: 1.7;
        }
        .content-subsection {
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #e8f0fe;
        }
        .content-subsection:first-of-type { margin-top: 0; padding-top: 0; border-top: 0; }
        .content-subsection__title {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            color: #0B2447;
            font-size: 14px;
            font-weight: 700;
        }
        .content-subsection__title i { color: #4DA6D9; }
        .footer {
            background: #0B2447; color: #b3d9ff;
            padding: 15px 0; text-align: center;
            margin-top: 30px; border-radius: 12px;
            font-size: 13px;
            border: 1px solid rgba(77,166,217,0.15);
        }
        .footer i { color: #4DA6D9; }
        @media (max-width: 992px) {
            .main-content { padding: 15px; }
        }
        @media (max-width: 768px) {
            .main-content { padding: 12px; }
            .page-title-banner { padding: 20px; text-align: center; border-radius: 16px; }
            .page-title-banner .underline { margin: 8px auto 0; }
            .page-title-banner h1 { font-size: 22px; }
            .content-section { padding: 18px 15px; border-radius: 14px; margin-bottom: 20px; }
            .content-section h2 { font-size: 17px; }
            .row { grid-template-columns: 1fr; gap: 12px; }
            .action-buttons { flex-direction: column-reverse; }
            .action-buttons .btn-back,
            .action-buttons .btn-save { width: 100%; justify-content: center; }
            .preview-section .image-display img { max-height: 150px; }
            .preview-section .image-display .placeholder-icon { height: 150px; font-size: 48px; }
            .footer { font-size: 11px; padding: 12px 10px; border-radius: 10px; margin-top: 20px; }
        }
        @media (max-width: 480px) {
            .sidebar { width: 85%; max-width: 300px; }
            .sidebar-header .logo .logo-icon { width: 40px; height: 40px; font-size: 18px; }
            .nav-link i { font-size: 14px; }
            .top-bar .page-title h1 { font-size: 17px; }
            .page-title-banner { padding: 15px; border-radius: 12px; }
            .page-title-banner h1 { font-size: 18px; }
            .content-section { padding: 15px 12px; border-radius: 12px; }
            .content-section h2 { font-size: 15px; }
            .form-group label { font-size: 13px; }
            .form-control { padding: 10px; font-size: 13px; }
            .preview-section { padding: 15px 12px; }
            .preview-section .image-display { padding: 10px; }
            .preview-section .image-display img { max-height: 120px; }
            .preview-section .image-display .placeholder-icon { height: 120px; font-size: 36px; }
            .preview-section .actions .btn-upload,
            .preview-section .actions .btn-remove {
                padding: 8px 16px;
                font-size: 12px;
            }
            .preview-section .file-input-wrapper .custom-file-label {
                padding: 8px 16px;
                font-size: 12px;
            }
            .footer { font-size: 10px; padding: 10px 8px; border-radius: 8px; margin-top: 15px; }
        }
        .logout-modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(11, 36, 71, 0.6);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            z-index: 99999;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: logoutFadeIn 0.2s ease;
            overscroll-behavior: contain;
        }
        .logout-modal-overlay.show { display: flex; }
        @keyframes logoutFadeIn { from { opacity: 0; } to { opacity: 1; } }
        .logout-modal {
            background: white;
            border-radius: 24px;
            max-width: 400px;
            width: 100%;
            padding: 35px 30px 25px;
            text-align: center;
            box-shadow: 0 30px 80px rgba(0,0,0,0.4);
            animation: logoutSlideIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            border-top: 6px solid #ef4444;
            max-height: 90vh;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        @keyframes logoutSlideIn {
            from { opacity: 0; transform: translateY(-30px) scale(0.9); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .logout-modal-icon {
            width: 80px; height: 80px;
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 18px;
            font-size: 36px; color: #ef4444;
            animation: logoutPulse 2s ease-in-out infinite;
        }
        @keyframes logoutPulse {
            0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.3); }
            50% { transform: scale(1.05); box-shadow: 0 0 0 15px rgba(239, 68, 68, 0); }
        }
        .logout-modal h3 {
            font-size: 22px; font-weight: 700;
            color: #991b1b; margin-bottom: 8px;
        }
        .logout-modal p {
            color: #64748b; font-size: 14px;
            line-height: 1.6; margin-bottom: 25px;
        }
        .btn-logout-cancel,
        .btn-logout-confirm {
            flex: 1;
            min-width: 130px;
            min-height: 48px;
            padding: 13px 18px;
            border: none; border-radius: 12px;
            font-weight: 700; font-size: 14px;
            cursor: pointer; transition: all 0.25s;
            display: inline-flex; align-items: center; justify-content: center;
            gap: 8px; text-decoration: none;
            -webkit-tap-highlight-color: rgba(0,0,0,0.1);
            touch-action: manipulation;
        }
        .btn-logout-cancel:hover,
        .btn-logout-cancel:active { background: #cbd5e1; transform: translateY(-2px); }
        .btn-logout-confirm {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }
        .btn-logout-confirm:hover,
        .btn-logout-confirm:active {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.45);
            color: white;
        }
        @media (max-width: 480px) {
            .logout-modal { padding: 28px 22px 20px; border-radius: 20px; }
            .logout-modal-icon { width: 65px; height: 65px; font-size: 28px; margin-bottom: 14px; }
            .logout-modal h3 { font-size: 19px; }
            .logout-modal p { font-size: 13px; margin-bottom: 20px; }
        }
    </style>
    <link rel="stylesheet" href="assets/css/admin-responsive.css">
</head>
<body>

<div class="app-container">
    <?php admin_layout_sidebar(['active' => 'content']); ?>

    <div class="main-content">

        <!-- TOP BAR -->
        <div class="top-bar">
            <div class="page-title">
                <h1>
                    <i class="fas fa-edit"></i> Edit Content
                    <span class="mobile-role-badge <?php echo $is_admin ? 'admin' : 'staff'; ?>">
                        <i class="fas fa-<?php echo $is_admin ? 'crown' : 'user-tie'; ?>"></i>
                        <?php echo $is_admin ? 'Admin' : 'Staff'; ?>
                    </span>
                    <span class="mobile-avatar" title="<?php echo htmlspecialchars($admin_display_name); ?>">
                        <?php if($admin_avatar): ?>
                            <img src="<?php echo htmlspecialchars($admin_avatar); ?>?<?php echo time(); ?>" alt="Avatar">
                        <?php else: ?>
                            <?php echo $admin_initial; ?>
                        <?php endif; ?>
                    </span>
                </h1>
                <p>Manage website branding, page banners, content, and GCash payment settings</p>
            </div>
            <div class="user-profile">
                <div class="user-info" style="text-align: right;">
                    <div class="user-name"><?php echo htmlspecialchars($admin_display_name); ?></div>
                    <div class="user-role">
                        <?php if($is_admin): ?>
                            <i class="fas fa-crown" style="color: #fbbf24;"></i> Admin
                        <?php else: ?>
                            <i class="fas fa-user-tie" style="color: #fbbf24;"></i> Staff
                        <?php endif; ?>
                    </div>
                </div>
                <div class="avatar">
                    <?php if($admin_avatar): ?>
                        <img src="<?php echo htmlspecialchars($admin_avatar); ?>?<?php echo time(); ?>" alt="Avatar">
                    <?php else: ?>
                        <?php echo $admin_initial; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if(isset($error)): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        <?php if(isset($success)): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
        <?php endif; ?>

        <!-- PAGE TITLE BANNER -->
        <div class="page-title-banner">
            <div class="banner-content">
                <h1><i class="fas fa-edit"></i> Edit Content</h1>
                <div class="underline"></div>
                <p>
                    Manage website branding, page banners, content, and GCash payment settings
                    <?php if($is_staff): ?>
                        <br><span class="staff-notice"><i class="fas fa-info-circle"></i> You are in View-Only mode. Contact Admin for changes.</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <?php if($is_staff): ?>
        <div class="view-only-banner">
            <i class="fas fa-eye"></i>
            <div>
                <strong>View-Only Mode</strong> — You can view all content but cannot make changes.
                Please contact an Administrator to update content.
            </div>
        </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">

            <!-- LOGO SECTION -->
            <div class="content-section logo-content-section">
                <div class="logo-section-intro">
                    <h2><i class="fas fa-image"></i> Website Logo</h2>
                    <p>Shown in the website header, navigation, and other branded areas.</p>
                </div>

                <div class="logo-manager">
                    <div class="logo-panel">
                        <div class="logo-card-label"><i class="fas fa-eye"></i> Current logo</div>
                        <div class="logo-current-preview">
                            <?php if($logo_exists): ?>
                                <img src="<?php echo htmlspecialchars($logo_path); ?>?<?php echo $cache_buster; ?>" alt="Current website logo">
                            <?php else: ?>
                                <div class="logo-current-placeholder" aria-label="No custom logo">
                                    <i class="fas fa-image"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="logo-current-details">
                            <div class="logo-current-name">
                                <strong><?php echo htmlspecialchars($site_name); ?></strong>
                                <span><?php echo $logo_exists ? 'Custom website logo' : 'No custom logo uploaded'; ?></span>
                            </div>
                            <?php if($logo_exists): ?>
                                <span class="logo-status-pill active"><i class="fas fa-check-circle"></i> Currently in use</span>
                            <?php else: ?>
                                <span class="logo-status-pill fallback"><i class="fas fa-info-circle"></i> Default branding</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if($is_admin): ?>
                        <div class="logo-panel">
                            <h3 class="logo-panel-title">Change website logo</h3>
                            <p class="logo-panel-copy">Select a new image below. Your current logo stays unchanged until you save the replacement.</p>

                            <label class="logo-upload-dropzone" id="logoDropzone" for="logoInput">
                                <input type="file" name="logo_image" id="logoInput" accept="image/jpeg,image/png,image/gif,image/webp,.jpg,.jpeg,.png,.gif,.webp">
                                <div class="logo-dropzone-default" id="logoDropzoneDefault">
                                    <div class="logo-upload-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                                    <strong>Select an image</strong>
                                    <span>or drag and drop it here</span>
                                </div>
                                <div class="logo-selected-state" id="logoSelectedState">
                                    <img class="logo-selected-preview" id="logoSelectedPreview" alt="Selected logo preview">
                                    <div class="logo-selected-info">
                                        <strong id="logoSelectedName">Selected image</strong>
                                        <span id="logoSelectedMeta">Ready to upload</span>
                                    </div>
                                    <span class="logo-ready-badge"><i class="fas fa-check"></i> Ready to save</span>
                                </div>
                            </label>

                            <div class="logo-upload-requirements">
                                <i class="fas fa-info-circle"></i>
                                <span>Use a square image for best results. PNG, JPG, GIF, or WEBP; recommended size 200 × 200 px or larger.</span>
                            </div>
                            <div class="logo-save-row">
                                <button type="submit" name="upload_logo" id="logoSaveBtn" class="logo-save-btn" disabled>
                                    <i class="fas fa-save"></i> Save New Logo
                                </button>
                            </div>
                        </div>

                        <?php if($logo_exists): ?>
                            <div class="logo-danger-zone">
                                <div>
                                    <strong>Remove website logo</strong>
                                    <p>The custom logo will be removed and the website will fall back to its default branding.</p>
                                </div>
                                <button type="button" class="logo-remove-button" onclick="openLogoRemoveModal()">
                                    <i class="fas fa-trash-alt"></i> Remove Logo
                                </button>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="logo-readonly-panel">
                            <i class="fas fa-lock"></i>
                            <div><strong>Logo management is restricted.</strong><br>Only administrators can replace or remove the website logo.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- PAGE BANNERS SECTION -->
            <div class="content-section banner-content-section">
                <div class="banner-section-intro">
                    <h2><i class="fas fa-images"></i> Page Banners</h2>
                    <p>Customize the large banner shown at the top of each guest page. Pages without their own banner automatically use the Homepage banner.</p>
                </div>

                <div class="banner-list">
                    <?php
                    $hero_sections = [
                        [
                            'label' => 'Homepage',
                            'description' => 'Main website landing page',
                            'exists' => $home_hero_exists,
                            'path' => $home_hero_path,
                            'fallback_exists' => false,
                            'fallback_path' => '',
                            'input' => 'home_hero_image',
                            'btn' => 'upload_home_hero',
                            'remove' => 'remove_home_hero',
                            'icon' => 'fa-home',
                            'prefix' => 'homeHero',
                        ],
                        [
                            'label' => 'Houses',
                            'description' => 'Guest accommodation page',
                            'exists' => $houses_hero_exists,
                            'path' => $houses_hero_path,
                            'fallback_exists' => $home_hero_exists,
                            'fallback_path' => $home_hero_path,
                            'input' => 'houses_hero_image',
                            'btn' => 'upload_houses_hero',
                            'remove' => 'remove_houses_hero',
                            'icon' => 'fa-home',
                            'prefix' => 'housesHero',
                        ],
                        [
                            'label' => 'Tours',
                            'description' => 'Boat and island tour page',
                            'exists' => $tours_hero_exists,
                            'path' => $tours_hero_path,
                            'fallback_exists' => $home_hero_exists,
                            'fallback_path' => $home_hero_path,
                            'input' => 'tours_hero_image',
                            'btn' => 'upload_tours_hero',
                            'remove' => 'remove_tours_hero',
                            'icon' => 'fa-umbrella-beach',
                            'prefix' => 'toursHero',
                        ],
                        [
                            'label' => 'Activities',
                            'description' => 'Guest activities page',
                            'exists' => $activities_hero_exists,
                            'path' => $activities_hero_path,
                            'fallback_exists' => $home_hero_exists,
                            'fallback_path' => $home_hero_path,
                            'input' => 'activities_hero_image',
                            'btn' => 'upload_activities_hero',
                            'remove' => 'remove_activities_hero',
                            'icon' => 'fa-water',
                            'prefix' => 'activitiesHero',
                        ],
                        [
                            'label' => 'Food',
                            'description' => 'Guest food and dining page',
                            'exists' => $food_hero_exists,
                            'path' => $food_hero_path,
                            'fallback_exists' => $home_hero_exists,
                            'fallback_path' => $home_hero_path,
                            'input' => 'food_hero_image',
                            'btn' => 'upload_food_hero',
                            'remove' => 'remove_food_hero',
                            'icon' => 'fa-utensils',
                            'prefix' => 'foodHero',
                        ],
                    ];
                    foreach ($hero_sections as $h):
                        $display_banner_exists = $h['exists'] || $h['fallback_exists'];
                        $display_banner_path = $h['exists'] ? $h['path'] : $h['fallback_path'];
                        $is_homepage = $h['prefix'] === 'homeHero';
                    ?>
                    <div class="banner-row" id="<?php echo $h['prefix']; ?>Row">
                        <div class="banner-page">
                            <div class="banner-page-icon"><i class="fas <?php echo $h['icon']; ?>"></i></div>
                            <div class="banner-page-copy">
                                <strong><?php echo htmlspecialchars($h['label']); ?></strong>
                                <span><?php echo htmlspecialchars($h['description']); ?></span>
                            </div>
                        </div>

                        <div class="banner-thumbnail">
                            <img
                                id="<?php echo $h['prefix']; ?>Preview"
                                src="<?php echo $display_banner_exists ? htmlspecialchars($display_banner_path) . '?' . $cache_buster : ''; ?>"
                                alt="<?php echo htmlspecialchars($h['label']); ?> banner preview"
                                <?php echo $display_banner_exists ? '' : 'style="display:none;"'; ?>
                            >
                            <div
                                class="banner-thumbnail-placeholder"
                                id="<?php echo $h['prefix']; ?>Placeholder"
                                <?php echo $display_banner_exists ? 'style="display:none;"' : ''; ?>
                            >
                                <i class="fas <?php echo $h['icon']; ?>"></i>
                            </div>
                            <?php if(!$h['exists'] && $h['fallback_exists']): ?>
                                <span class="banner-thumbnail-fallback" id="<?php echo $h['prefix']; ?>FallbackBadge">Homepage fallback</span>
                            <?php else: ?>
                                <span class="banner-thumbnail-fallback" id="<?php echo $h['prefix']; ?>FallbackBadge" style="display:none;">Homepage fallback</span>
                            <?php endif; ?>
                        </div>

                        <div class="banner-controls">
                            <div class="banner-state">
                                <?php if($h['exists']): ?>
                                    <span class="banner-status-pill custom" id="<?php echo $h['prefix']; ?>Status"><i class="fas fa-check-circle"></i> Custom banner</span>
                                    <small id="<?php echo $h['prefix']; ?>Meta">Currently shown on this page</small>
                                <?php elseif($h['fallback_exists']): ?>
                                    <span class="banner-status-pill fallback" id="<?php echo $h['prefix']; ?>Status"><i class="fas fa-layer-group"></i> Using Homepage banner</span>
                                    <small id="<?php echo $h['prefix']; ?>Meta">Add a custom banner only when this page needs a different image.</small>
                                <?php else: ?>
                                    <span class="banner-status-pill fallback" id="<?php echo $h['prefix']; ?>Status"><i class="fas fa-image"></i> Default background</span>
                                    <small id="<?php echo $h['prefix']; ?>Meta">No custom banner is currently stored.</small>
                                <?php endif; ?>
                            </div>

                            <div class="banner-actions">
                                <?php if($is_admin): ?>
                                    <input
                                        class="banner-file-input"
                                        type="file"
                                        name="<?php echo $h['input']; ?>"
                                        id="<?php echo $h['prefix']; ?>Input"
                                        accept="image/jpeg,image/png,image/gif,image/webp,.jpg,.jpeg,.png,.gif,.webp"
                                    >
                                    <label class="banner-select-btn" for="<?php echo $h['prefix']; ?>Input" id="<?php echo $h['prefix']; ?>SelectLabel">
                                        <i class="fas fa-image"></i>
                                        <span><?php echo $h['exists'] ? 'Change Banner' : 'Add Banner'; ?></span>
                                    </label>
                                    <button
                                        type="submit"
                                        name="<?php echo $h['btn']; ?>"
                                        class="banner-save-btn"
                                        id="<?php echo $h['prefix']; ?>SaveBtn"
                                        disabled
                                    >
                                        <i class="fas fa-save"></i> Save Banner
                                    </button>
                                    <?php if($h['exists']): ?>
                                        <a
                                            href="?<?php echo $h['remove']; ?>=1"
                                            class="banner-reset-btn"
                                            onclick="return confirm('<?php echo $is_homepage ? 'Remove the Homepage banner? Pages without a custom banner will use the default background.' : 'Remove this custom banner and use the Homepage banner instead?'; ?>')"
                                        >
                                            <i class="fas fa-undo-alt"></i>
                                            <?php echo $is_homepage ? 'Remove Custom' : 'Use Homepage'; ?>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="banner-readonly"><i class="fas fa-lock"></i> Admin only</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="banner-guidance">
                    <i class="fas fa-info-circle"></i>
                    <span>For best results, use a wide landscape image at 1600 × 600 px or larger. JPG, PNG, GIF, and WEBP are supported.</span>
                </div>
            </div>

            <!-- GCASH QR CODE SECTION -->
            <div class="content-section">
                <h2><i class="fas fa-qrcode"></i> GCash QR Code</h2>
                <div class="preview-section">
                    <h5 style="color: #1e293b; font-weight: 600; margin-bottom: 15px;">Current QR Code</h5>
                    <div class="image-display">
                        <?php if($gcash_qr_exists): ?>
                            <img src="<?php echo htmlspecialchars($gcash_qr_path); ?>?<?php echo $cache_buster; ?>" alt="GCash QR Code" style="max-width: 200px; max-height: 200px;">
                            <div class="status active"><i class="fas fa-check-circle"></i> QR Code is active</div>
                        <?php else: ?>
                            <div class="placeholder-icon"><i class="fas fa-qrcode"></i></div>
                            <div class="status inactive"><i class="fas fa-info-circle"></i> No QR Code uploaded</div>
                        <?php endif; ?>
                    </div>
                    <?php if($is_admin): ?>
                        <div class="actions">
                            <div class="file-input-wrapper">
                                <input type="file" name="gcash_qr" id="gcashQrInput" accept="image/*">
                                <div class="custom-file-label" id="gcashQrFileLabel">
                                    <i class="fas fa-upload"></i>
                                    <span id="gcashQrFileLabelText">Choose QR image</span>
                                </div>
                            </div>
                            <button type="submit" name="upload_gcash_qr" class="btn-upload">
                                <i class="fas fa-upload"></i> Upload QR Code
                            </button>
                            <?php if($gcash_qr_exists): ?>
                                <a href="?remove_gcash_qr=1" class="btn-remove" onclick="return confirm('Remove the GCash QR code?')">
                                    <i class="fas fa-trash"></i> Remove QR Code
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="file-name-display" id="gcashQrFileNameDisplay">No file selected</div>
                        <div class="size-info"><i class="fas fa-info-circle"></i> Upload GCash QR code image (PNG, JPG, JPEG, GIF)</div>
                    <?php else: ?>
                        <div style="padding: 10px; background: #f1f5f9; border-radius: 8px; color: #94a3b8;">
                            <i class="fas fa-lock" style="color: #f59e0b;"></i> Only Admin can upload QR code
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- GCASH SETTINGS SECTION -->
            <div class="content-section">
                <h2><i class="fas fa-mobile-alt"></i> GCash Payment Settings</h2>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> GCash Account Name</label>
                    <input type="text" name="content[gcash][account_name]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                           value="<?php echo htmlspecialchars($content['gcash']['account_name'] ?? 'Juan Dela Cruz'); ?>"
                           <?php echo $is_staff ? 'disabled' : ''; ?>>
                    <div class="text-muted">Name registered in GCash account</div>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-mobile-alt"></i> GCash Number</label>
                    <input type="text" name="content[gcash][number]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                           value="<?php echo htmlspecialchars($content['gcash']['number'] ?? '09123456789'); ?>"
                           <?php echo $is_staff ? 'disabled' : ''; ?>>
                    <div class="text-muted">GCash mobile number (e.g., 09123456789)</div>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-info-circle"></i> Payment Instructions</label>
                    <textarea name="content[gcash][instructions]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                              rows="6" <?php echo $is_staff ? 'disabled' : ''; ?>><?php echo htmlspecialchars($content['gcash']['instructions'] ?? "1. Open GCash app\n2. Click 'Pay QR' or 'Scan QR'\n3. Scan the QR code above\n4. Enter the exact amount shown\n5. Complete the payment\n6. Take a screenshot of the transaction\n7. Upload screenshot as proof of payment"); ?></textarea>
                    <div class="text-muted">Instructions for guests on how to pay via GCash (one per line)</div>
                </div>
            </div>

            <!-- HOMEPAGE INTRODUCTION -->
            <div class="content-section">
                <h2><i class="fas fa-home"></i> Homepage Introduction</h2>
                <p class="section-description">Edit the main heading and supporting text shown at the top of the guest homepage.</p>

                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Main Heading</label>
                    <input type="text" name="content[hero][title]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                           value="<?php echo htmlspecialchars($content['hero']['title'] ?? 'Welcome to Transient House & Tours'); ?>"
                           <?php echo $is_staff ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Supporting Text</label>
                    <textarea name="content[hero][subtitle]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                              rows="3" <?php echo $is_staff ? 'disabled' : ''; ?>><?php echo htmlspecialchars($content['hero']['subtitle'] ?? 'Your home away from home and gateway to unforgettable island adventures.'); ?></textarea>
                </div>
            </div>

            <!-- BOOKING CALL TO ACTION -->
            <div class="content-section">
                <h2><i class="fas fa-bullhorn"></i> Booking Call to Action</h2>
                <p class="section-description">Control the short booking message shown near the bottom of the homepage. Navigation button labels and destinations are managed by the system for consistency.</p>

                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Heading</label>
                    <input type="text" name="content[cta][title]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                           value="<?php echo htmlspecialchars($content['cta']['title'] ?? 'Ready to Book Your Stay?'); ?>"
                           <?php echo $is_staff ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Supporting Text</label>
                    <textarea name="content[cta][subtitle]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                              rows="3" <?php echo $is_staff ? 'disabled' : ''; ?>><?php echo htmlspecialchars($content['cta']['subtitle'] ?? 'Choose from our comfortable houses or exciting tour packages for your next adventure.'); ?></textarea>
                </div>

                <div class="system-actions-preview" aria-label="System-managed homepage actions">
                    <strong>Fixed homepage actions:</strong>
                    <span class="system-action-chip"><i class="fas fa-home"></i> View Houses</span>
                    <span class="system-action-chip"><i class="fas fa-box-open"></i> Build a Package</span>
                </div>
            </div>

            <!-- BUSINESS INFORMATION -->
            <div class="content-section">
                <h2><i class="fas fa-building"></i> Business Information</h2>
                <p class="section-description">Manage the contact details and location shown to guests across the website.</p>

                <div class="content-subsection">
                    <div class="content-subsection__title"><i class="fas fa-info-circle"></i> About & Contact</div>
                    <div class="form-group">
                        <label>Business Description</label>
                        <textarea name="content[footer][company_description]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                                  rows="3" <?php echo $is_staff ? 'disabled' : ''; ?>><?php echo htmlspecialchars($content['footer']['company_description'] ?? 'Your trusted partner for comfortable accommodations and exciting island adventures.'); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="form-group">
                            <label><i class="fas fa-phone"></i> Phone</label>
                            <input type="text" name="content[footer][phone]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                                   value="<?php echo htmlspecialchars($content['footer']['phone'] ?? '+63 912 345 6789'); ?>"
                                   <?php echo $is_staff ? 'disabled' : ''; ?>>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email</label>
                            <input type="email" name="content[footer][email]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                                   value="<?php echo htmlspecialchars($content['footer']['email'] ?? 'info@transientrental.com'); ?>"
                                   <?php echo $is_staff ? 'disabled' : ''; ?>>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Business Address</label>
                        <input type="text" name="content[location][address]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                               value="<?php echo htmlspecialchars($location_address); ?>"
                               <?php echo $is_staff ? 'disabled' : ''; ?>
                               placeholder="Inansuana, Lucap, Alaminos, Philippines, 2404">
                        <div class="help-text"><i class="fas fa-info-circle"></i> This is the single address used for guest-facing location links and footer information.</div>
                    </div>
                </div>

                <div class="content-subsection">
                    <div class="content-subsection__title"><i class="fas fa-share-alt"></i> Social Media</div>
                    <div class="form-group">
                        <label><i class="fab fa-facebook-f" style="color:#1877f2;"></i> Facebook Page URL</label>
                        <input type="url" name="content[social][facebook]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                               value="<?php echo htmlspecialchars(($content['social']['facebook'] ?? '') === '#' ? '' : ($content['social']['facebook'] ?? '')); ?>"
                               <?php echo $is_staff ? 'disabled' : ''; ?>
                               placeholder="https://www.facebook.com/yourpage">
                        <div class="help-text"><i class="fas fa-info-circle"></i> Leave this empty to hide the Facebook link from the guest footer.</div>
                    </div>
                </div>

                <div class="content-subsection">
                    <div class="content-subsection__title"><i class="fas fa-map"></i> Google Maps</div>
                    <div class="form-group">
                        <label>Google Maps Embed Link</label>
                        <textarea name="content[location][google_maps_embed]" class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                                  rows="3" <?php echo $is_staff ? 'disabled' : ''; ?>
                                  placeholder="https://www.google.com/maps/embed?pb=..."><?php echo htmlspecialchars($google_maps_embed); ?></textarea>
                        <div class="help-text"><i class="fas fa-info-circle"></i> Paste the Google Maps embed link. Leave it empty to hide the map.</div>

                        <details class="help-disclosure">
                            <summary><i class="fas fa-circle-question"></i> How to get the Google Maps embed link</summary>
                            <div class="help-disclosure__body">
                                1. Open <a href="https://www.google.com/maps" target="_blank" rel="noopener">Google Maps</a> and find the business location.<br>
                                2. Select <strong>Share</strong>, then <strong>Embed a map</strong>.<br>
                                3. Copy only the iframe <strong>src</strong> link that begins with <strong>https://www.google.com/maps/embed</strong>.<br>
                                4. Paste that link into the field above.
                            </div>
                        </details>
                    </div>

                    <div style="margin-top:15px;padding:15px;background:#f8fafc;border-radius:12px;border:1px solid #e8f0fe;">
                        <label style="font-weight:600;color:#1e293b;margin-bottom:10px;display:block;">
                            <i class="fas fa-eye" style="color:#4DA6D9;margin-right:6px;"></i> Map Preview
                        </label>
                        <?php if (!empty($google_maps_embed) && $google_maps_embed != '#'): ?>
                            <iframe src="<?php echo htmlspecialchars($google_maps_embed); ?>" width="100%" height="250"
                                    style="border:0;border-radius:10px;" allowfullscreen="" loading="lazy"
                                    referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php else: ?>
                            <div style="text-align:center;padding:28px;background:#f1f5f9;border-radius:10px;color:#94a3b8;">
                                <i class="fas fa-map" style="font-size:36px;display:block;margin-bottom:10px;color:#cbd5e1;"></i>
                                <p style="margin:0;">No map configured. Add a Google Maps embed link above to show a preview.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- TERMS & PRIVACY SECTION -->
            <div class="content-section">
                <h2><i class="fas fa-file-contract"></i> Legal Information</h2>

                <div class="form-section-title"><i class="fas fa-lock"></i> Terms & Conditions <span style="font-size:11px;color:#f59e0b;margin-left:6px;">Locked</span></div>
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Terms Title</label>
                    <input type="text" name="content[terms][title]"
                           class="form-control form-control-readonly"
                           value="<?php echo htmlspecialchars($content['terms']['title'] ?? 'Terms & Conditions'); ?>"
                           disabled aria-readonly="true">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-paragraph"></i> Terms Content</label>
                    <textarea name="content[terms][body]"
                              class="form-control form-control-readonly"
                              rows="14"
                              disabled aria-readonly="true"><?php echo htmlspecialchars($content['terms']['body'] ?? 'Welcome to Transient House & Tours. By booking with us, you agree to the following terms:

1. BOOKING & RESERVATIONS
• All bookings are subject to availability and confirmation.
• A valid government-issued ID is required during check-in.
• The lead guest must be at least 18 years old.'); ?></textarea>
                    <div class="help-text" style="color:#64748b;"><i class="fas fa-lock" style="color:#f59e0b;"></i> Terms & Conditions are locked and cannot be edited from this panel.</div>
                </div>

                <div class="form-section-title"><i class="fas fa-shield-alt"></i> Privacy Policy</div>
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> Privacy Title</label>
                    <input type="text" name="content[privacy][title]"
                           class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                           value="<?php echo htmlspecialchars($content['privacy']['title'] ?? 'Privacy Policy'); ?>"
                           <?php echo $is_staff ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-paragraph"></i> Privacy Content</label>
                    <textarea name="content[privacy][body]"
                              class="form-control <?php echo $is_staff ? 'form-control-readonly' : ''; ?>"
                              rows="14"
                              <?php echo $is_staff ? 'disabled' : ''; ?>><?php echo htmlspecialchars($content['privacy']['body'] ?? 'Your privacy is important to us. This policy explains what information we collect and how we use it.'); ?></textarea>
                    <div class="help-text"><i class="fas fa-info-circle"></i> Basic HTML is supported.</div>
                </div>

                <div style="background: #f8fafc; border-radius: 10px; padding: 12px 15px; margin-top: 15px; border: 1px solid #e8f0fe;">
                    <div style="font-size: 12px; color: #64748b;">
                        <i class="fas fa-fingerprint" style="color: #4DA6D9;"></i>
                        <strong>Current Version:</strong>
                        <code style="background: #e8f0fe; padding: 2px 8px; border-radius: 4px; color: #0B2447;"><?php echo $current_terms_version; ?></code>
                        <span style="margin-left: 8px;">— Terms & Conditions are locked. Editing the Privacy Policy will change this acceptance version and require users to accept the updated policy on next login.</span>
                    </div>
                </div>
            </div>

            <div class="action-buttons">
                <a href="index.php" target="_blank" class="btn-back"><i class="fas fa-eye"></i> Preview Site</a>
                <?php if($is_admin): ?>
                    <button type="submit" name="update_content" class="btn-save"><i class="fas fa-save"></i> Save Content Changes</button>
                <?php else: ?>
                    <button type="button" class="btn-save" disabled>
                        <i class="fas fa-lock"></i> Save Disabled (View-Only)
                    </button>
                <?php endif; ?>
            </div>
        </form>

        <div class="footer">
            <p>
                <i class="fas fa-umbrella-beach"></i>
                &copy; <?php echo date('Y'); ?> Transient House &amp; Tours. All rights reserved.
                <span style="opacity: 0.3; margin: 0 10px;">|</span>
                <span style="color: #7bb8f0; font-size: 11px;">
                    <i class="fas fa-user-shield"></i>
                    <?php echo $is_admin ? 'Administrator' : 'Staff'; ?> Access
                </span>
            </p>
        </div>
    </div>
</div>

<?php if($is_admin && $logo_exists): ?>
<!-- WEBSITE LOGO REMOVAL CONFIRMATION -->
<div class="logo-remove-modal-overlay" id="logoRemoveModal" role="dialog" aria-modal="true" aria-labelledby="logoRemoveModalTitle">
    <div class="logo-remove-modal">
        <div class="logo-remove-modal-icon"><i class="fas fa-trash-alt"></i></div>
        <h3 id="logoRemoveModalTitle">Remove website logo?</h3>
        <p>The current custom logo will no longer appear on the website. Default branding will be used instead.</p>
        <form method="POST" class="logo-remove-modal-actions">
            <button type="button" class="logo-modal-cancel" onclick="closeLogoRemoveModal()">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button type="submit" name="remove_logo" value="1" class="logo-modal-confirm">
                <i class="fas fa-trash-alt"></i> Remove Logo
            </button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php admin_layout_footer(); ?>

<script>
// FILE INPUT PREVIEW HANDLERS
function handleFileInput(inputId, labelId, labelTextId, displayId, defaultLabel) {
    var input = document.getElementById(inputId);
    if (!input) return;

    input.addEventListener('change', function() {
        var file = this.files && this.files[0];
        var label = document.getElementById(labelId);
        var labelText = document.getElementById(labelTextId);
        var display = document.getElementById(displayId);

        if (file) {
            if (label) label.classList.add('has-file');
            if (labelText) labelText.textContent = file.name;
            if (display) {
                display.textContent = 'Selected: ' + file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)';
            }
        } else {
            if (label) label.classList.remove('has-file');
            if (labelText) labelText.textContent = defaultLabel;
            if (display) display.textContent = 'No file selected';
        }
    });
}

handleFileInput('gcashQrInput', 'gcashQrFileLabel', 'gcashQrFileLabelText', 'gcashQrFileNameDisplay', 'Choose QR image');

// PAGE BANNER UPLOADERS
(function initPageBannerUploaders() {
    const prefixes = ['homeHero', 'housesHero', 'toursHero', 'activitiesHero', 'foodHero'];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    function formatBytes(bytes) {
        if (!Number.isFinite(bytes) || bytes <= 0) return '';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    prefixes.forEach(function(prefix) {
        const input = document.getElementById(prefix + 'Input');
        const row = document.getElementById(prefix + 'Row');
        const preview = document.getElementById(prefix + 'Preview');
        const placeholder = document.getElementById(prefix + 'Placeholder');
        const fallbackBadge = document.getElementById(prefix + 'FallbackBadge');
        const status = document.getElementById(prefix + 'Status');
        const meta = document.getElementById(prefix + 'Meta');
        const selectLabel = document.getElementById(prefix + 'SelectLabel');
        const saveBtn = document.getElementById(prefix + 'SaveBtn');

        if (!input) return;

        input.addEventListener('change', function() {
            const file = this.files && this.files[0] ? this.files[0] : null;
            if (!file) return;

            if (allowedTypes.indexOf(file.type) === -1) {
                this.value = '';
                alert('Please choose a JPG, PNG, GIF, or WEBP image.');
                return;
            }

            if (row) row.classList.add('is-selected');
            if (saveBtn) saveBtn.disabled = false;
            if (fallbackBadge) fallbackBadge.style.display = 'none';

            if (status) {
                status.className = 'banner-status-pill ready';
                status.innerHTML = '<i class="fas fa-check"></i> Ready to save';
            }
            if (meta) meta.textContent = file.name + ' • ' + formatBytes(file.size);
            if (selectLabel) {
                const labelText = selectLabel.querySelector('span');
                if (labelText) labelText.textContent = 'Choose Different';
            }

            if (preview && window.FileReader) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    if (placeholder) placeholder.style.display = 'none';
                };
                reader.readAsDataURL(file);
            }
        });
    });
})();

// WEBSITE LOGO UPLOADER
(function initLogoUploader() {
    const input = document.getElementById('logoInput');
    const dropzone = document.getElementById('logoDropzone');
    const defaultState = document.getElementById('logoDropzoneDefault');
    const selectedState = document.getElementById('logoSelectedState');
    const preview = document.getElementById('logoSelectedPreview');
    const nameEl = document.getElementById('logoSelectedName');
    const metaEl = document.getElementById('logoSelectedMeta');
    const saveBtn = document.getElementById('logoSaveBtn');

    if (!input || !dropzone) return;

    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    function formatBytes(bytes) {
        if (!Number.isFinite(bytes) || bytes <= 0) return '';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    function showSelectedFile(file) {
        if (!file) {
            if (defaultState) defaultState.style.display = '';
            if (selectedState) selectedState.classList.remove('show');
            if (saveBtn) saveBtn.disabled = true;
            if (preview) preview.removeAttribute('src');
            return;
        }

        if (allowedTypes.indexOf(file.type) === -1) {
            input.value = '';
            showSelectedFile(null);
            alert('Please choose a JPG, PNG, GIF, or WEBP image.');
            return;
        }

        if (nameEl) nameEl.textContent = file.name;
        if (metaEl) metaEl.textContent = formatBytes(file.size) + ' • Click this area to choose a different image';
        if (defaultState) defaultState.style.display = 'none';
        if (selectedState) selectedState.classList.add('show');
        if (saveBtn) saveBtn.disabled = false;

        if (preview && window.FileReader) {
            const reader = new FileReader();
            reader.onload = function(e) { preview.src = e.target.result; };
            reader.readAsDataURL(file);
        }
    }

    input.addEventListener('change', function() {
        showSelectedFile(this.files && this.files[0] ? this.files[0] : null);
    });

    ['dragenter', 'dragover'].forEach(function(eventName) {
        dropzone.addEventListener(eventName, function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add('dragover');
        });
    });

    ['dragleave', 'drop'].forEach(function(eventName) {
        dropzone.addEventListener(eventName, function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
        });
    });

    dropzone.addEventListener('drop', function(e) {
        const files = e.dataTransfer && e.dataTransfer.files;
        if (!files || !files.length) return;

        const file = files[0];
        try {
            const transfer = new DataTransfer();
            transfer.items.add(file);
            input.files = transfer.files;
        } catch (err) {
            // Some browsers block programmatic FileList assignment; visual preview still works.
        }
        showSelectedFile(file);
    });
})();

function openLogoRemoveModal() {
    const modal = document.getElementById('logoRemoveModal');
    if (!modal) return;
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    const cancelBtn = modal.querySelector('.logo-modal-cancel');
    if (cancelBtn) setTimeout(function() { cancelBtn.focus(); }, 50);
}

function closeLogoRemoveModal() {
    const modal = document.getElementById('logoRemoveModal');
    if (!modal) return;
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
}

(function initLogoRemoveModal() {
    const modal = document.getElementById('logoRemoveModal');
    if (!modal) return;
    modal.addEventListener('click', function(e) {
        if (e.target === modal) closeLogoRemoveModal();
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('show')) {
            closeLogoRemoveModal();
        }
    });
})();

// AUTO-HIDE ALERTS
setTimeout(function() {
    document.querySelectorAll('.alert').forEach(function(alert) {
        alert.style.opacity = '0';
        alert.style.transition = 'opacity 0.5s';
        setTimeout(() => alert.remove(), 500);
    });
}, 5000);
</script>

</body>
</html>